from bisheng.interface.custom.custom_component import CustomComponent

__all__ = ["CustomComponent"]
