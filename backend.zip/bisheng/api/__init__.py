from bisheng.api.router import router, router_rpc

__all__ = ['router', 'router_rpc']
