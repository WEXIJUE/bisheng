from cryptography.fernet import Fernet

# 使用正确的密钥
secret_key = 'TI31VYJ-ldAq-FXo5QNPKV_lqGTFfp-MIdbK2Hm5F1E='
fernet = Fernet(secret_key)

# 加密密码
encrypted_password = fernet.encrypt(b"123456")
print(encrypted_password.decode())  # 输出加密后的字符串
