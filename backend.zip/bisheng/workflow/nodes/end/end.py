from bisheng.workflow.nodes.base import BaseNode


class EndNode(BaseNode):

    def _run(self, unique_id: str):
        return None
