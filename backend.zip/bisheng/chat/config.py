class ChatConfig:
    streaming: bool = True
